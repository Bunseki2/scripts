/*
 * This is the faster version for solving
 * y = (K + lambda*I)^(-1)*y
 *
 *
 *
 */




#include <RcppArmadillo.h>
//[[Rcpp::depends(RcppArmadillo)]]
//#include <Rcpp.h> // do not need the header

using namespace Rcpp;
using namespace arma;
using namespace std;

// [[Rcpp::export]]
arma::vec fastSolve(arma::mat A, arma::vec y, arma::uword numTr, arma::uword lambda) {
  // NB: here use '*' to multiply scalar to eye matrix
  return solve(A + lambda * eye<mat>(numTr, numTr), y);
}
