/*


 calculate K = exp(-dist(Xj, Xi) / sigma)
 this function was wrote by using c++ by kevin


*/






#include <RcppArmadillo.h>
//[[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp;
using namespace std;
using namespace arma;

// [[Rcpp::export]]
arma::mat fastKgipMat(NumericMatrix AA, double sigma0) {
  // AA, adjacent matrix [0, 1]

  // avoid change AA values
  NumericMatrix Ar = clone(AA);
  int m = Ar.nrow(),
      k = Ar.ncol();
  // fast assign Ar to A, when use false
  arma::mat A = arma::mat(Ar.begin(), m, k, false);
  // construct sigma
  double sigma = sigma0 * (accu(square(A)) / m); // note: it is m, not k
  // use arma::mat member function
  arma::colvec An =  sum(square(A), 1);
  // use: norm decomposition to fast calculate squared euclidean distance: matlab: pdist
	// google: Pairwise distances in R | f3lix
  arma::mat C = -2 * (A * A.t());
  C.each_col() += An;
  C.each_row() += An.t();
  // C is squared EU distance matrix
  // Kmat is Gaussian (similarity) matrix

  arma::mat Kmat = exp(-(C / sigma));
  return Kmat;
}
