## demo for RLS-KF using NRs data set
data(NRs)

y <- nr_adj
y <- as.matrix(y)

simmatCompd <- nr_sim_dc
simmatCompd <- as.matrix(simmatCompd)

simmatTarget <- nr_sim_dg
simmatTarget <- as.matrix(simmatTarget)

if (!isSymmetric(simmatCompd)) simmatCompd <- (simmatCompd + t(simmatCompd))/2
## check matrix positive semi-definite:
epsilon <- 0.1
while (!is.positive.semi.definite(simmatCompd)) simmatCompd <- simmatCompd + epsilon * diag(nrow(simmatCompd))
## for NR, simmatTarget is positive semi-definite
## check matrix symmetric
if (!isSymmetric(simmatTarget)) simmatTarget <- (simmatTarget + t(simmatTarget))/2
## check matrix positive semi-definite:
epsilon <- 0.1
while (!is.positive.semi.definite(simmatTarget)) simmatTarget <- simmatTarget + epsilon * diag(nrow(simmatTarget))


ttest <- RLS_KF_pred(y = y, simmatCompd = simmatCompd, simmatTarget = simmatTarget)
cat("Average aggregation gives the results based on 10-fold CV:\n")

ttest$stat_ave_mean

