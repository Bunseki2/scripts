#'
#' consecutive cross-validation: useful for batch download data frome NCBI,
#' in order to avoid overhead
#' Herein, numPerFold to tell the program to put these number into this fold
#'
#' @param N: number of elements in a vect
#' @param numPerFold: number of element for each fold
#' @return a list with numberPerFold
#'
#'
#'
#'



cvConsecutive <- function(N, numPerFold = 5) {
  k <- ceiling(N / numPerFold)
  length.seg <- ceiling(N / k)
  incomplete <- k * length.seg - N
  complete <- k - incomplete
  if (complete < k) {
    inds <- cbind(matrix(1:(length.seg * complete), nrow = length.seg),
                  rbind(matrix((length.seg * complete + 1):N, nrow = length.seg - 1), NA))
  } else {
    inds <- matrix(1:N, nrow = length.seg)
  }
  res_lst <- lapply(as.data.frame(inds), function(x) c(na.omit(x)))
  return(res_lst)
}

