#'
#'  Main function to do DTI prediction with RLS-KF and save the file onto disk
#'
#' @param nreps: number of trials of cross-validation
#' @param gamma0: for Kgip, default 1
#' @param lambda: for (K + lambda * diag()), default 1
#' @param nfold: number of cross-validation, default 1
#' @param numNeig: number of neighbourbers for kernel fusion
#' @param numIter: number of iterations for kernel fusion
#' @param y: adjacency matrix for drug-target interaction profiles
#' @param simmatCompd: kenel matrix for compounds
#' @param simmatTarget: kernel matrix for targets
#' @param dsName: data set name, default 'dsName'
#'
#' @return do not return anything, just save them onto disk it is "*.RData" file
#'
#'
#'


RLS_KF_pred <- function(nreps   = 10,         ## number of trails for crossvalidation
                        gamma0  = 1,          ## for Kgip, default 1
                        lambda  = 1,          ## for (K + lambda * diag()), default 1
                        nfold   = 10,         ## crossvalidation, default 10
                        numNeig = 4,          ## number of neibourber for kernel fusion
                                              ## for NR, default 4
                                              ## for GPCR, default 3
                                              ## for IC, default 3
                                              ## for enzyme, default 4
                        numIter = 2,          ## number of iteration steps for kernel fusion
                                              ## for NR, default 2
                                              ## for GPCR, default 2
                                              ## for IC, default 2
                                              ## for enzyme, default 5
                        y,                    ## ajdacency matrix for interaction profile
                        simmatCompd,          ## kernel matrix between compounds
                        simmatTarget          ## kernel matrix between targets
                        ) {


  predProb_ave_lst <- vector(mode = "list", length = nreps)
  predProb_max_lst <- vector(mode = "list", length = nreps)

  stat_ave <- matrix(0, nrow = nreps, ncol = 13)
  colnames(stat_ave) <- c("auc", "aupr", "auprFrom",
                          "sen1", "spe1", "gmean1", "mcc1", "F1",
                          "sen3", "spe3", "gmean3", "mcc3", "F3")

  stat_max <- matrix(0, nrow = nreps, ncol = 13)
  colnames(stat_max) <- c("auc", "aupr", "auprFrom",
                          "sen1", "spe1", "gmean1", "mcc1", "F1",
                          "sen3", "spe3", "gmean3", "mcc3", "F3")

  auc_ave_lst <- vector(mode = "list", length = nreps)
  aupr_ave_lst <- vector(mode = "list", length = nreps)

  auc_max_lst <- vector(mode = "list", length = nreps)
  aupr_max_lst <- vector(mode = "list", length = nreps)

  for (i_trials in 1:nreps) {

	  ## (1) do prediction based on the target similarity
	  yTarget <- y
	  numRows <- nrow(yTarget)
	  numCols <- ncol(yTarget)
	  predBasedTarget <- matrix(0, nr = numRows, nc = numCols)
	  myColPrediction <- matrix(0, nr = numRows, nc = 1)

	  ## Either using similarity matrix as kernel matrix or change them to kernel matrix
	  needK <- FALSE
	  if (needK) {
		  ## kernel matrix for targets
		  dst4simmat <- 1/simmatTarget
		  medianV <- fastMatMedian(dst4simmat)
		  k4simmat <- exp(-dst4simmat / (gamma1 * medianV))  ## gamma1 = 0.2 by default
	  } else {
		  k4simmat <- simmatTarget
	  }

	  ## cross-validation folds
	  folds <- getCVFolds(numRows, nfold)  ## function created by Kevin

	  #Rprof("rprof", line.profiling = TRUE)
	  #tStart <- Sys.time()
	  ## main fold prediction function
	  for (i in 1:numCols) {
		  if (i %% 20 == 0) cat("1: ", i, "/", numCols, " -- ", i_trials, "/", nreps, "\n"); flush.console()
		  currY <- yTarget[, i]
		  currSim2 <- simmatCompd[, i]  ## used when train Y values are all zeros: estimated Y = yLeave %*% currSim2
		  for (j in 1:nfold) {
			  idxTe <- folds[[j]]
			  idxTr <- setdiff(1:numRows, idxTe)
			  yLeave <- yTarget
			  yLeave[idxTe, i] <- 0
			  yLeaveSum <- sum(yLeave[, i]) ## when current Y values are zeros,
			                                ## we can NOT build model: c = (K + lambda * I)^(-1) %*% currY
			  ## main fold function
			  myColPrediction[idxTe, 1] <- SMF_DTI(
				  currY        = currY,
				  yLeave       = yLeave,
				  yLeaveSum    = yLeaveSum,
				  currSim2     = currSim2,
				  idxTr        = idxTr,
				  idxTe        = idxTe,
				  simmat       = simmatTarget,
				  simmat2      = simmatCompd,
				  gamma0       = gamma0,
				  numNeig      = numNeig,
				  numIter      = numIter,
				  lambda       = lambda,
				  k4simmat     = k4simmat)
		  }
		  predBasedTarget[, i] <- myColPrediction
	  }
	  #Rprof(NULL)
	  #summaryRprof("rprof", lines = "show")


	  ## (2) do prediction based on the compound similarity
	  yCompd <- t(y)
	  numRows <- nrow(yCompd)
	  numCols <- ncol(yCompd)
	  predBasedCompd <- matrix(0, nr = numRows, nc = numCols)
	  myColPrediction <- matrix(0, nr = numRows, nc = 1)

	  ## kernel matrix for targets
	  needK <- FALSE
	  if (needK) {
		  dst4simmat <- 1 / simmatCompd
		  medianV <- fastMatMedian(dst4simmat)
		  k4simmat <- exp(-dst4simmat / (gamma1 * medianV)) ## gamma1 = 0.2 by default
	  } else {
		  k4simmat <- simmatCompd
	  }

	  ## cross-validation folds
    folds <- getCVFolds(numRows, nfold)  ## function created by Kevin

	  ## main fold prediction function
	  for (i in 1:numCols) {
		  if (i %% 20 == 0) cat("2: ", i, "/", numCols, " -- ", i_trials, "/", nreps, "\n"); flush.console()
		  currY <- yCompd[, i]
		  ## used when train Y values are all zeros, get estimated Y = yLeave %*% currSim2
		  currSim2 <- simmatTarget[, i]
		  for (j in 1:nfold) {
			  idxTe <- folds[[j]]
			  idxTr <- setdiff(1:numRows, idxTe)
			  yLeave <- yCompd
			  yLeave[idxTe, i] <- 0
			  ## when current Y values are zeros, can NOT build model: c = (K + lambda * I)^(-1) %*% currY
			  yLeaveSum <- sum(yLeave[, i])
			  ## main fold function
			  myColPrediction[idxTe, 1] <- SMF_DTI(
				  currY      = currY,
				  yLeave     = yLeave,
				  yLeaveSum  = yLeaveSum,
				  currSim2   = currSim2,
				  idxTr      = idxTr,
				  idxTe      = idxTe,
				  simmat     = simmatCompd,
				  simmat2    = simmatTarget,
				  gamma0     = gamma0,
				  numNeig    = numNeig,
				  numIter    = numIter,
				  lambda     = lambda,
				  k4simmat   = k4simmat)
		  }
		  predBasedCompd[, i] <- myColPrediction
	  }


	  ## (3) statistics
	  ## (3-1) average
	  yLabel <- as.vector(y)
	  predProb_ave <- (predBasedTarget + t(predBasedCompd))/2
	  predProb_ave_lst[[i_trials]] <- predProb_ave
	  finalPred <- as.vector(predProb_ave)
	  statRes_ave <- calAUPR(yLabel, finalPred)  ## function coded by kevin
    stat_ave[i_trials, ] <- statRes_ave        ## save all nreps's results
	  stat_ave_mean <- apply(stat_ave, 2, mean)
	  stat_ave_sd <- apply(stat_ave, 2, sd)
	  pred <- ROCR::prediction(finalPred, yLabel)
	  perfAUC <- ROCR::performance(pred, "tpr", "fpr")
    #x11()
	  #plot(perfAUC)
	  fpr <- unlist(perfAUC@x.values)
	  tpr <- unlist(perfAUC@y.values)
	  #x11()
	  #plot(fpr, tpr, type = "l")
    fpr_tpr <- cbind(fpr, tpr)
	  auc_ave_lst[[i_trials]] <- fpr_tpr
	  perfAUPR <- ROCR::performance(pred, "prec", "rec")
	  #x11()
	  #plot(perfAUPR)
	  recall <- unlist(perfAUPR@x.values)
	  precision <- unlist(perfAUPR@y.values)
	  #plot(recall, precision, type = "l")
	  rec_prec <- cbind(recall, precision)
	  aupr_ave_lst[[i_trials]] <- rec_prec


	  ## (3-2) maximum
	  yLabel <- as.vector(y)
	  predBasedCompd <- t(predBasedCompd)
	  predProb_max <- ifelse(predBasedTarget > predBasedCompd, predBasedTarget, predBasedCompd)
	  predProb_max_lst[[i_trials]] <- predProb_max ## save all predicted probability when max
	  finalPred <- as.vector(predProb_max)
	  statRes_max <- calAUPR(yLabel, finalPred)  ## function coded by kevin

	  ###########   save all nreps's results   #############
    stat_max[i_trials, ] <- statRes_max
	  stat_max_mean <- apply(stat_max, 2, mean)
	  stat_max_sd <- apply(stat_max, 2, sd)

	  ########### ROC curve and AUPR curve  #################
	  pred <- ROCR::prediction(finalPred, yLabel)
	  perfAUC <- ROCR::performance(pred, "tpr", "fpr")
    #x11()
	  #plot(perfAUC)
	  fpr <- unlist(perfAUC@x.values)
	  tpr <- unlist(perfAUC@y.values)
	  #x11()
	  #plot(fpr, tpr, type = "l")
    fpr_tpr <- cbind(fpr, tpr)
	  auc_max_lst[[i_trials]] <- fpr_tpr  ## save false positive rate and true positive rate
	  perfAUPR <- ROCR::performance(pred, "prec", "rec") ## AUPR
	  #x11()
	  #plot(perfAUPR)
	  recall <- unlist(perfAUPR@x.values)
	  precision <- unlist(perfAUPR@y.values)
	  #plot(recall, precision, type = "l")
	  rec_prec <- cbind(recall, precision)
	  aupr_max_lst[[i_trials]] <- rec_prec ## save recall and persion

	  ## cost time
	  #tEnd <- Sys.time()
	  #tEnd - tStart
  }
  wholeResults <- list(predProb_ave_lst = predProb_ave_lst,
                       stat_ave         = stat_ave,
                       stat_ave_mean    = stat_ave_mean,
                       stat_ave_sd      = stat_ave_sd,
                       auc_ave_lst      = auc_ave_lst,
                       aupr_ave_lst     = aupr_ave_lst,
                       ## max results
                       predProb_max_lst = predProb_max_lst,
                       stat_max         = stat_max,
                       stat_max_mean    = stat_max_mean,
                       stat_max_sd      = stat_max_sd,
                       auc_max_lst      = auc_max_lst,
                       aupr_max_lst     = aupr_max_lst)

  return(wholeResults)
}
