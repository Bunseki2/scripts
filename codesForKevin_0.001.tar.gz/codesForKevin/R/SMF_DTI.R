## try to use foreach on windows 7
## RRO use multiple cores already, *** no need parallel, foreach ***
## RRO 8.0.2 seems to have better math library for performance
##:: MKL will only use the 'physical cores' (i.e., 4), rather than hyper-threads (i.e., 8) ::
## do 'fold prediction' for test set



#' Calculate Similarity Fusiong for Drug-Target-Interaction
#'
#' @param currY
#' @param yLeave
#' @param yLeaveSum
#' @param currSim2
#' @param idxTr
#' @param idxTe
#' @param simmat
#' @param simmat2
#' @param gamma0
#' @param numNeig
#' @param numIter
#' @param lambda
#' @param k4simmat
#'
#' @return prediction for each fold
#'
#'
#'


SMF_DTI <- function(
  currY        = currY,
  yLeave       = yLeave,
  yLeaveSum    = yLeaveSum,
  currSim2     = currSim2,
  idxTr        = idxTr,
  idxTe        = idxTe,
  simmat       = simmatTarget,
  simmat2      = simmatCompd,
  gamma0       = 1,      ## gamma0, for Kgip, defaul 1
  numNeig      = 3,      ## number of neighbors, default 3
  numIter      = 2,      ## number of iterators, default 2
  lambda       = 1,      ## lambda, for (K + lambda * diag()): "Kernel Regularized Least Squares: Moving Beyond Linearity and Additivity Without Sacrificing Interpretability"
  k4simmat     = k4simmat)
{
  #====================================================
	## Gaussian kernel matrix
  Kgip <- fastKgipMat(yLeave, gamma0) # c++
  ## all were wrote by c++, a little different from SNF function located in SNFtool package, for K largest neighbours
	K <- fastSMF(Kgip, k4simmat, numNeig, numIter) # c++
	#====================================================

  ## all current yTr = 0, no way to do prediction, so use NII to generate values
  if (yLeaveSum == 0) {
    ## 'NII' is the key here to inductive prediction
    ## simmat2 is on the 'top' of y adjacent matrix, simmat is on the 'left' of y adjacent matrix!
    currYe <- yLeave %*% currSim2
    currYe[idxTe] <- 0
    # normalize [0, 1]
    currY <- (currYe - min(currYe)) / (max(currYe) - min(currYe))
    K1 <- K[idxTr, idxTr, drop = FALSE]
    yTr <- currY[idxTr]
    ## test set: similarity between test and training samples
    K2 <- K[idxTe, idxTr, drop = FALSE]
    ## training model
    numTrainSet <- length(idxTr)

	  ## check the K1 property
	  #cat(is.positive.semi.definite(K1), "\n")
    ## model y = Ax, where x(i.e., model) = (A^-1) %*% y
		## chance coefficient c = ((K + lambda * I)^(-1)) %*% y
		## ref page 8: Kernel Regularized Least Squares: Moving Beyond Linearity and Additivity Without Sacrificing Interpretability
    model <- fastSolve(K1, yTr, numTrainSet, lambda)         ## c++

    ## Fold predicted values for test set
    myFoldPrediction <- matrix(0, nrow = length(idxTe), ncol = 1)

    ## check if current test set is new.
    ## e.g., for new coming target, which is no interaction with known drugs.
    ## OR, for new coming drug, which is no interaction with known targets.
    hasZeros <- which(apply(yLeave[idxTe, ], 1, sum) == 0)

    if (length(hasZeros) == 0) {
      ## none of test set is new
      myFoldPrediction[, 1] <- K2 %*% model
    } else if (length(hasZeros) == length(idxTe)) {
      ## all test sets are new: prediction based on the similarity itself rather than K2
      myFoldPrediction[, 1] <- simmat[idxTe, idxTr, drop = FALSE] %*% model
    } else {
      ## some of test set are new, and others are not
      ## (1) test set are new
      idxZeros <- idxTe[hasZeros]
      myFoldPrediction[hasZeros, 1] <- simmat[idxZeros, idxTr, drop = FALSE] %*% model
      ## (2) test set are not new
      idxNotZeros <- setdiff(1:length(idxTe), hasZeros)
      myFoldPrediction[idxNotZeros, 1] <- K2[idxNotZeros, , drop = FALSE] %*% model
    }
  } else { ## current y include at least 1, which then can be used to build model, no need NII
    K1 <- K[idxTr, idxTr, drop = FALSE]
    yTr <- currY[idxTr]
    K2 <- K[idxTe, idxTr, drop = FALSE]
    numTrainSet <- length(idxTr)

    ## model
    model <- fastSolve(K1, yTr, numTrainSet, lambda) ## c++

    ## prediction for current fold
    myFoldPrediction <- matrix(0, nrow = length(idxTe), ncol = 1)

    ## check if current test set is new.
    ## e.g., for new coming target, which is no interaction with known drugs.
    ## OR, for new coming drug, which is no interaction with known targets
    hasZeros <- which(apply(yLeave[idxTe, ], 1, sum) == 0)

    if (length(hasZeros) == 0) {
      ## none of all test set is new
      myFoldPrediction[, 1] <- K2 %*% model
    } else if (length(hasZeros) == length(idxTe)) {
      ## all test sets are new
      myFoldPrediction[, 1] <- simmat[idxTe, idxTr, drop = FALSE] %*% model
    } else {
      ## some of test set are new, and others are not
      ## (1) test set are new
      idxZeros <- idxTe[hasZeros]
      myFoldPrediction[hasZeros, 1] <- simmat[idxZeros, idxTr, drop = FALSE] %*% model
      ## (2) test set are not new
      idxNotZeros <- setdiff(1:length(idxTe), hasZeros)
      myFoldPrediction[idxNotZeros, 1] <- K2[idxNotZeros, , drop = FALSE] %*% model
    }
  }
  return(myFoldPrediction)
}
