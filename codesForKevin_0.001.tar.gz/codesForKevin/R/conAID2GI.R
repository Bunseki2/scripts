#' PubChem AID To Protein GI at NCBI
#' code by Kevin on Feb-16-2015
#'
#' @param aid: a vector of aid
#' @param lenEachFold: length of each fold, for batch convert, not one by one
#' default 400, since the maximum is 500 for each time at NCBI eutils
#'
#' @return aid_gi: data.frame for aid and corresponding gi
#'
#'
#'
#'
#'
#'
#'
#'

conAID2GI <- function(aid, lenEachFold = 1) {
  folds <- cvConsecutive(length(aid), lenEachFold)
  ## Initialize a matrix
  aid_gi <- matrix(NA, nrow = length(aid), ncol = 2)
  colnames(aid_gi) <- c("aid", "gi")
  ## Main loop
  ## library(reutils) ## have in the Imports in DESCRIPTION
  ## library(XML)
  for (i in 1:length(folds)) {
    curInd <- folds[[i]]
    ## NB: maximum records are 500, 'reutils' package
    ## library(reutils)
    doc <- esummary(aid[curInd], db = "pcassay")
    doc <- doc["//GI"]
    ## Extract first element for each node. Sometimes each SID return many CID
    ## Such as, SID = "17398008", "7847378", "17397364", this is because the main
    ## CID have unique components for each complex CID and in this case it has multiple
    ## CIDs for the SID, and some SID has not CID
    ## Such as, SID = 17397364, then it returns "\n\t"
    ## library(XML)
    curGIs <- sapply(doc, function(x) xmlValue(xmlChildren(x)[[1]]))  ## extract the first element
    aid_gi[curInd, "aid"] <- aid[curInd]
    aid_gi[curInd, "gi"] <- curGIs
  }
  # Post-check every AID have corresponding GI
  noGI <- which(aid_gi[, "gi"] %in% "\\n\\t")
  cat("Which AID does not include GI?\n")
  print(noGI)
  cat("---done!---\n")

  aid_gi <- apply(aid_gi, 2, as.numeric)
  ## library(data.table)
  ## aid_gi <- as.data.frame(aid_gi)
  ## setDT(aid_gi)

  return(aid_gi)

  ## Save the file and will be used on Linux
  ## save(aidVSgi, file = "aidVSgi2031.RData")
  ## Check the number for aids and targets
  ## aid_gi <- apply(aid_gi, 2, as.numeric)
  ## 662 targets
  ## length(unique(aid_gi[, "gi"]))
  ## 2031 aids, Here is unique aid, less targets
  ## means that different aids have the same targets
  ## length(unique(aid_gi[, "aid"]))
  ## is.numeric(aid_gi[, "gi"]) # Check if other bad class in the column
}
