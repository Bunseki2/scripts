#'
#' function to calculate the AUCR and AUC as well as sensitivity and specificity, MCC etc.
#'
#'
#' @param obsLabel: observed labels
#' @param predProb: predicted probabilities
#'
#' @return calculated statistical metrics
#'
#'


calAUPR <- function(obsLabel, predProb) {

	## top 1% and 3% of predicted probabilities as positive
	lab_prob <- cbind(obsLabel, predProb)
	## decreased order
	lab_prob <- lab_prob[order(-lab_prob[, "predProb"]), ]
	#head(lab_prob)
	nSamples <- nrow(lab_prob)
	## 1% and 3%
	r1 <- ceiling(nSamples * 1/100)
	r3 <- ceiling(nSamples * 3/100)
	## backup: LP1 and LP3
	LP1 <- lab_prob
	LP3 <- lab_prob
	## assign 'hard' labels for predicted probabilities
	LP1[1:r1, 2] <- 1
	LP1[(r1 + 1):nSamples, 2] <- 0
	LP3[1:r3, 2] <- 1
	LP3[(r3 + 1):nSamples, 2] <- 0

	#source("calStat10.R")
	percent1 <- calStat10(LP1[, "obsLabel"], LP1[, "predProb"])  ## function created by kevin
	percent3 <- calStat10(LP3[, "obsLabel"], LP3[, "predProb"])


	## calculate AUC using ROCR
	#library('ROCR')
  pred <- ROCR::prediction(predProb, obsLabel)
  perf <- ROCR::performance(pred, "auc")
	#str(perf)
  auc <- as.numeric(perf@y.values)

  ## calculate AUPR using ROCR
  #library('ROCR')
  perf <- ROCR::performance(pred, 'rec', 'prec')
	#str(perf)
  Precision <- unlist(perf@x.values)
  Recall <- unlist(perf@y.values)


  ## this one is good
  ## 'linear' does not work
  ## library('MESS')
  ## note: 'try' is good function: note, namespace
	## give error for enzyme, so using 'try'
  aupr_spline <- try(MESS::auc(Recall, Precision, type = 'spline'), silent = TRUE)
  ## aupr <- MESS::auc(Recall, Precision, type = 'linear') ## NA

  ## library('pracma') ## for solve integral, but not work
  ## aupr <- trapz(Recall, Precision) ## NaN


	## create a data.frame to save the result
	statRes <- matrix(0, nrow = 1, ncol = 13)
	colnames(statRes) <- c("auc", "aupr", "auprFrom",
	                       "sen1", "spe1", "gmean1", "mcc1", "F1",
												 "sen3", "spe3", "gmean3", "mcc3", "F3")

  if (class(aupr_spline) == 'try-error') {
    ## this function does work when MESS::auc function in
    ## MESS does not work
    ## library('Bolstad2')
    ## uses Simpson's rule: numerical integrating, solve the area
    aupr_simpson <- sintegral(Recall, Precision)$int # 0.9299252 for enzyme
    ## save
		statRes[, "auc"] <- auc
		statRes[, "aupr"] <- aupr_simpson
		## auprFrom = 1, 'spline'
    ## auprFrom = 2, 'Simpson rule'
		statRes[, "auprFrom"] <- 2
		## 1%
		statRes[, "sen1"] <- percent1["sen"]
		statRes[, "spe1"] <- percent1["spe"]
		statRes[, "gmean1"] <- percent1["gmean"]
		statRes[, "mcc1"] <- percent1["mcc"]
		statRes[, "F1"] <- percent1["F"]
    ## 3%
		statRes[, "sen3"] <- percent3["sen"]
		statRes[, "spe3"] <- percent3["spe"]
		statRes[, "gmean3"] <- percent3["gmean"]
		statRes[, "mcc3"] <- percent3["mcc"]
		statRes[, "F3"] <- percent3["F"]
		return(statRes)
  } else {
    statRes[, "auc"] <- auc
		statRes[, "aupr"] <- aupr_spline
		## auprFrom = 1, 'spline'
    ## auprFrom = 2, 'Simpson rule'
		statRes[, "auprFrom"] <- 1
		## 1%
		statRes[, "sen1"] <- percent1["sen"]
		statRes[, "spe1"] <- percent1["spe"]
		statRes[, "gmean1"] <- percent1["gmean"]
		statRes[, "mcc1"] <- percent1["mcc"]
		statRes[, "F1"] <- percent1["F"]
    ## 3%
		statRes[, "sen3"] <- percent3["sen"]
		statRes[, "spe3"] <- percent3["spe"]
		statRes[, "gmean3"] <- percent3["gmean"]
		statRes[, "mcc3"] <- percent3["mcc"]
		statRes[, "F3"] <- percent3["F"]
		return(statRes)
  }
}

