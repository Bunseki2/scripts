





#' get cross-validation folds
#'
#' @param num: number of samples
#' @param nfold: how many folds you want to get
#' @return folds: obtained folds



getCVFolds <- function(num, nfold) {
  lenSeg <- ceiling(num / nfold)
  incomplete <- nfold * lenSeg - num
  complete <- nfold - incomplete
  inds <- matrix(c(sample(1:num), rep(NA, incomplete)), nrow = lenSeg, byrow = TRUE)
  folds <- lapply(as.data.frame(inds), function(x) c(na.omit(x)))
  return(folds)
}
