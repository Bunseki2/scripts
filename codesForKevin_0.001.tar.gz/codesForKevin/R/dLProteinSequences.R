#'
#'
#' download protein sequences of fasta format from NCBI using eutils
#'
#' @param gi: a vector of gi number
#' @param db: set to protein which is database name use in ncbi
#' @param rettype: set to fasta
#' @param retmodel: set to text, OR XML
#' @param lenEachFold: number of a pool when batch download, maximum is 500, we often set 400
#' @param fname: saved file name
#' @return retrieved GIs, to check if all GIs can be downloaded sequences
#'
#'
#'
dLProtSequences <- function(gi, db = "protein", rettype = "fasta",
                            retmode = "text", lenEachFold = 1, fname = "dL_seq") {

  ## retrieved gis
  retGIs <- vector(mode = "list")


  folds <- cvConsecutive(length(gi), lenEachFold)
  for (i in 1:length(folds)) {
    curInd <- folds[[i]]
    dL     <- efetch(gi[curInd], db = db, rettype = "fasta", retmode = "xml")
    ## only sequence
    protSeq <- dL["//TSeq_sequence"]
    protSeq <- sapply(protSeq, function(x) xmlValue(xmlChildren(x)[[1]]))
    ## onley gi
    protGi <- dL["//TSeq_gi"]
    protGi <- sapply(protGi, function(x) xmlValue(xmlChildren(x)[[1]]))
    ## only reference id
    protRef <- dL["//TSeq_accver"]
    protRef <- sapply(protRef, function(x) xmlValue(xmlChildren(x)[[1]]))
    ## protein names
    protName <- dL["//TSeq_defline"]
    protName <- sapply(protName, function(x) xmlValue(xmlChildren(x)[[1]]))
    ## combine these, which is header of each sequences
    protHeader <- paste0(">gi", "|", protGi, "|", "ref", "|", protRef, "|", protName)
    ## number of retrieved sequence for current fold
    numSeq <- length(protSeq)
    if (numSeq == 0) {
      next() ## when no sequence can be retrieved then do next for loop: like continue in other language
    } else {

      retGIs[[i]] <- protGi ## to test if all GIs can be downloaded sequences

      ## even row index
      evenRowIdx <- seq(2, 2 * numSeq, 2)
      ## odd row index
      oddRowIdx <- seq(1, 2 * numSeq - 1, 2)
      ## pool to save these
      pool <- matrix(NA, nrow = 2 * numSeq, ncol = 1)
      pool[oddRowIdx, 1] <- protHeader
      pool[evenRowIdx, 1] <- protSeq
      write.table(pool[, 1], file = paste0(fname, ".fasta"), quote = F, row.names = F, col.names = F, append = TRUE)
    }
  }

  retGIs <- unlist(retGIs)

  LL <- retGIs %in% gi
  if (sum(LL) != length(gi)) {
    cat("\nSome GIs can not be download sequences!\n")
    badGI_L <- !(gi %in% retGIs)
    badGIs <- gi[badGI_L]
    cat("\nBad GIs are:\n ", badGIs, "\n\n")
  } else {
    cat("All GIs can be downloaded, good!\n\n")
  }


  return(retGIs)
}


## for test
## cd()
## aa <- dLProtSequences(c(3220020101, 822564876, 822564877), fname = "aa") ## 3220020101 bad GI
## aa <- dLProtSequences(c(822564868, 822564876, 822564877, 822564861), lenEachFold = 2)
## for test: read fasta and write fasta
## aa <- readAAStringSet("c:/users/kevin/desktop/a.fasta")
## writeXStringSet(aa, filepath = "c:/users/kevin/desktop/aa.fasta")

