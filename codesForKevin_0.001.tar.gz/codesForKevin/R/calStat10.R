#'
#' Calculate 10 statistical metrics
#'
#' @param y: observed labels
#' @param yPred: predicted labels
#'
#' @return 10 statistical metrics
#'
#'
#'
#'
#'
#'


calStat10 <- function(y, yPred) {

	## Prompt information
  ## cat("First argument: y; Second argument: y.pred.\n")

	## usually, 1 for Active and 0 for Inactive
  if (is.numeric(y)) {
    whichMax_y <- which(y == max(y))
    whichMin_y <- which(y == min(y))
    y[whichMax_y] <- "Active"
    y[whichMin_y] <- "Inactive"

    whichMax_yPred <- which(yPred == max(yPred))
    whichMin_yPred <- which(yPred == min(yPred))
    yPred[whichMax_yPred] <- "Active"
    yPred[whichMin_yPred] <- "Inactive"
  }


  TP <- length(subset(yPred[y == "Active"], yPred[y == "Active"] == "Active"))
	TN <- length(subset(yPred[y == "Inactive"], yPred[y == "Inactive"] == "Inactive"))
	FP <- length(subset(yPred[y == "Inactive"], yPred[y == "Inactive"] == "Active"))
	FN <- length(subset(yPred[y == "Active"], yPred[y == "Active"] == "Inactive"))


	## sensitivity :-> recall: True positive Rate (Acc^+)
	sen <- TP / (TP + FN)
	## specificity: True negative rate (Ac^-)
	spe <- TN / (TN + FP)
	## accuracy
	acc <- (TP + TN)/(TP + FP + TN + FN)
	a <- TP + FP
	b <- TP + FN
	## c is built-in function, so use "cc" instead of "c"
	cc <- TN + FN
	d <- TN + FP
	## fen mu
	denominator <- as.numeric(a) * as.numeric(b) * as.numeric(cc) * as.numeric(d)
	## Matthews correlation coefficient
	mcc <- (TP * TN - FP * FN) / sqrt(denominator)
	## precision :-> ppv: positive predictive value
	pre <- TP / (TP + FP)
	## recall
	rec <- sen
	F <- 2 * (pre * rec / (pre + rec))
	## G-mean
	gmean <- sqrt(sen * spe)
	## weighted accuracy
	wacc <- 0.5 * (sen + spe)
	err <- 1 - acc

	## 10 statistical metrics
	statistics10 <- c(sen = sen,
				             spe = spe,
				             gmean = gmean,
                     wacc = wacc,
                     acc = acc,
				             mcc = mcc,
				             pre = pre,
				             rec = rec,
				             F = F,
				             err = 1 - acc)
	return(statistics10)
}
